package com.example.convid_19selfscreeningtool;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class MainActivity extends AppCompatActivity {
    EditText mFullname, mAge, mLga, mCommunity, mPhonenumber;
    Spinner stateSpinner;
    RadioGroup mGender, mCough, mFever, mDifficultyInBreathing, mSneezing, mChestPain, mDiarrhoea, mFlu, mSoreThroatSymptoms,
            mContactWithFever, mContactWithCough, mContactWithDifficultBreathing, mContactWithSneeze, mContactWithChestpain,
            mContactWithDiarrhoea, mContactWithOtherFLu, mContactWithSoreThroat, mUnderlyingConditions, mSpecifyKidney, mSpecifyPregnancy,
            mSpecifyHIVandTB,
            mSpecifyDiabetes, mSpecifyLiver, mSpecifyChronicLungDisease, mSpecifyCancer, mSpecifyHeartDisease;
    RadioButton rb, rb2, rb3, rb4, rb5, rb6, rb7, rb8, rb9, rb10, rb11, rb12, rb13, rb14, rb15, rb16, rb17, rb18, rb19, rb20, rb21, rb22, rb23, rb24, rb25, rb26;
    Button mBtn_submit;

    ProgressBar mProgressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mFullname = findViewById(R.id.edit_text_fullname);
        mAge = findViewById(R.id.edit_text_age);
        mLga = findViewById(R.id.edit_text_lga);
        mCommunity = findViewById(R.id.edit_text_community);
        mPhonenumber = findViewById(R.id.edit_text_phone);

        mProgressBar = findViewById(R.id.progressBar);

        mGender = findViewById(R.id.radio_gender);
        mFever = findViewById(R.id.radio_fever);
        mCough = findViewById(R.id.radio_cough);
        mDifficultyInBreathing = findViewById(R.id.radio_difficultBreathing);
        mSneezing = findViewById(R.id.radio_sneezingSymptoms);
        mChestPain = findViewById(R.id.radio_chestpainSymptoms);
        mDiarrhoea = findViewById(R.id.radio_diarrhoeaSymptoms);
        mFlu = findViewById(R.id.radio_fluSymptoms);
        mSoreThroatSymptoms = findViewById(R.id.radio_soreSymptoms);
        mContactWithFever = findViewById(R.id.radio_contactWithFever);
        mContactWithCough = findViewById(R.id.radio_contactWithCough);
        mContactWithDifficultBreathing = findViewById(R.id.radio_contactWithDifficultBreathing);
        mContactWithSneeze = findViewById(R.id.radio_contactWithSneeze);
        mContactWithChestpain = findViewById(R.id.radio_contactWithChestpain);
        mContactWithDiarrhoea = findViewById(R.id.radio_contactWithDiarrhoea);
        mContactWithOtherFLu = findViewById(R.id.radio_contactWithOtherFLu);
        mContactWithSoreThroat = findViewById(R.id.radio_contactWithSoreThroat);
        mUnderlyingConditions = findViewById(R.id.radio_condition);
        mSpecifyHIVandTB = findViewById(R.id.specifyHIVandTB);
        mSpecifyDiabetes = findViewById(R.id.radio_specifyDiabetes);
        mSpecifyLiver = findViewById(R.id.radio_specifyLiverDisease);
        mSpecifyChronicLungDisease = findViewById(R.id.radio_chronicLungDisease);
        mSpecifyCancer = findViewById(R.id.radio_specifyCancer);
        mSpecifyHeartDisease = findViewById(R.id.radio_heartDisease);

        mSpecifyKidney = findViewById(R.id.radio_specifyKidney);
        mSpecifyPregnancy = findViewById(R.id.radio_specifyPregnancy);


        mBtn_submit = findViewById(R.id.btn_submit);

        stateSpinner = findViewById(R.id.spinner);

        mProgressBar.setVisibility(View.GONE);

        mBtn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String fullname = mFullname.getText().toString().trim();
                final String age = mAge.getText().toString().trim();
                final String phone = mPhonenumber.getText().toString();
                final String gender = rb.getText().toString();
                final String state = String.valueOf(stateSpinner.getSelectedItem());
                final String lga = mLga.getText().toString().trim();
                final String community = mCommunity.getText().toString().trim();
                final String feverSymptom = rb2.getText().toString();
                final String coughSymptom = rb3.getText().toString();
                final String difficultyInBreathingSymptom = rb4.getText().toString();
                final String sneezingSymptoms = rb5.getText().toString();
                final String chestPainSymptoms = rb6.getText().toString();
                final String diarrhoeaSymptoms = rb7.getText().toString();
                final String fluSymptoms = rb8.getText().toString();
                final String soreThroatSymptoms = rb9.getText().toString();
                final String contactWithFever = rb10.getText().toString();
                final String contactWithCough = rb11.getText().toString();
                final String contactWithDifficultBreathing = rb12.getText().toString();
                final String contactWithSneeze = rb13.getText().toString();
                final String contactWithChestpain = rb14.getText().toString();
                final String contactWithDiarrhoea = rb15.getText().toString();
                final String contactWithOtherFLu = rb16.getText().toString();
                final String contactWithSoreThroat = rb17.getText().toString();
                final String underlyingConditions = rb18.getText().toString();
                final String specifyKidney = rb19.getText().toString();
                final String specifyPregnancy = rb20.getText().toString();
                final String specifyHIVandTB = rb21.getText().toString();
                final String specifyDiabetes = rb22.getText().toString();
                final String specifyLiver = rb23.getText().toString();
                final String specifyChronicLungDisease = rb24.getText().toString();
               final  String specifyCancer = rb25.getText().toString();
                final String specifyHeartDisease = rb26.getText().toString();


                if (TextUtils.isEmpty(fullname)) {
                    mFullname.setError("Please Enter your Full name!");
                    mFullname.requestFocus();
                    return;
                }

                if (TextUtils.isEmpty(age)) {
                    mAge.setError("Please Enter your Age!");
                    mAge.requestFocus();
                    return;
                }

                if (TextUtils.isEmpty(lga)) {
                    mLga.setError("Please Enter your LGA!");
                    mLga.requestFocus();
                    return;
                }


                if (TextUtils.isEmpty(community)) {
                    mCommunity.setError("Please Enter your Community!");
                    mCommunity.requestFocus();
                    return;

                }
                mProgressBar.setVisibility(View.VISIBLE);
                Patients patients = new Patients(fullname, age, phone, gender, state, lga, community, feverSymptom, coughSymptom, difficultyInBreathingSymptom,
                        sneezingSymptoms, chestPainSymptoms, diarrhoeaSymptoms, fluSymptoms, soreThroatSymptoms, contactWithFever, contactWithCough,
                        contactWithDifficultBreathing, contactWithSneeze, contactWithChestpain, contactWithDiarrhoea, contactWithOtherFLu,
                        contactWithSoreThroat, underlyingConditions, specifyKidney, specifyPregnancy,specifyHIVandTB,specifyDiabetes, specifyLiver, specifyChronicLungDisease,
                        specifyCancer, specifyHeartDisease
                );

                patients.setFullname(fullname);
                patients.setAge(age);
                patients.setPhone(phone);
                patients.setGender(gender);
                patients.setState(state);
                patients.setLga(lga);
                patients.setCommunity(community);
                patients.setFeverSymptom(feverSymptom);
                patients.setCoughSymptom(coughSymptom);
                patients.setDifficultyInBreathingSymptom(difficultyInBreathingSymptom);
                patients.setSneezingSymptoms(sneezingSymptoms);
                patients.setChestPainSymptom(chestPainSymptoms);
                patients.setDiarrhoeaSymptoms(diarrhoeaSymptoms);
                patients.setSoreThroatSymptoms(soreThroatSymptoms);


                //Get database reference
                final DatabaseReference mPatients = FirebaseDatabase.getInstance().getReference("patients");
                //keep in sync
                mPatients.keepSynced(true);
                // new patient node would be created
                String patientData = mPatients.push().getKey();
                //System.out.println("Record - " + patientData);
                // pushing user to 'users' node using the userId
                assert patientData != null;
                //Task<Void> saveData = mPatients.child(patientData).child(fullname).setValue(patients);
                Task<Void> saveData = mPatients.child(patientData).child(fullname).setValue(patients);
                if (!saveData.isSuccessful()) {
                    Toast.makeText(MainActivity.this, "Data Saved Successfully", Toast.LENGTH_LONG).show();
                    mProgressBar.setVisibility(View.GONE);
                    Intent intent = new Intent(MainActivity.this, MessageActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(MainActivity.this, "Error Saving Data", Toast.LENGTH_SHORT).show();
                    mProgressBar.setVisibility(View.GONE);
                }

            }
        });


// Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.state_arrays, android.R.layout.simple_spinner_dropdown_item);
// Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        stateSpinner.setAdapter(adapter);
    }

    public void onRadioButtonClicked(View view) {
        int radioButtonId = mGender.getCheckedRadioButtonId();
        rb = findViewById(radioButtonId);

        int radioButton1d2 = mFever.getCheckedRadioButtonId();
        rb2 = findViewById(radioButton1d2);

        int radioButtonid3 = mCough.getCheckedRadioButtonId();
        rb3 = findViewById(radioButtonid3);

        int radioButton1d4 = mDifficultyInBreathing.getCheckedRadioButtonId();
        rb4 = findViewById(radioButton1d4);

        int radioButton1d5 = mSneezing.getCheckedRadioButtonId();
        rb5 = findViewById(radioButton1d5);

        int radioButton1d6 = mChestPain.getCheckedRadioButtonId();
        rb6 = findViewById(radioButton1d6);

        int radioButton1d7 = mChestPain.getCheckedRadioButtonId();
        rb7 = findViewById(radioButton1d7);

        int radioButton1d8 = mChestPain.getCheckedRadioButtonId();
        rb8 = findViewById(radioButton1d8);

        int radioButton1d9 = mChestPain.getCheckedRadioButtonId();
        rb9 = findViewById(radioButton1d9);
        int radioButtonId10 = mContactWithFever.getCheckedRadioButtonId();
        rb10 = findViewById(radioButtonId10);

        int radioButtonId11 = mContactWithCough.getCheckedRadioButtonId();
        rb11 = findViewById(radioButtonId11);

        int radioButtonId12 = mContactWithDifficultBreathing.getCheckedRadioButtonId();
        rb12 = findViewById(radioButtonId12);

        int radioButtonId13 = mContactWithSneeze.getCheckedRadioButtonId();
        rb13 = findViewById(radioButtonId13);

        int radioButtonId14 = mContactWithChestpain.getCheckedRadioButtonId();
        rb14 = findViewById(radioButtonId14);

        int radioButtonId15 = mContactWithDiarrhoea.getCheckedRadioButtonId();
        rb15 = findViewById(radioButtonId15);

        int radioButtonId16 = mContactWithOtherFLu.getCheckedRadioButtonId();
        rb16 = findViewById(radioButtonId16);

        int radioButtonId17 = mContactWithSoreThroat.getCheckedRadioButtonId();
        rb17 = findViewById(radioButtonId17);

        int radioButtonId18 = mUnderlyingConditions.getCheckedRadioButtonId();
        rb18 = findViewById(radioButtonId18);

        int radioButtonId19 = mSpecifyKidney.getCheckedRadioButtonId();
        rb19 = findViewById(radioButtonId19);

        int radioButtonId20 = mSpecifyPregnancy.getCheckedRadioButtonId();
        rb20 = findViewById(radioButtonId20);

//
        int radioButtonId21 = mSpecifyHIVandTB.getCheckedRadioButtonId();
        rb21 = findViewById(radioButtonId21);

        int radioButtonId22 = mSpecifyDiabetes.getCheckedRadioButtonId();
        rb22 = findViewById(radioButtonId22);

        int radioButtonId23 = mSpecifyLiver.getCheckedRadioButtonId();
        rb23 = findViewById(radioButtonId23);
        int radioButtonId24 = mSpecifyChronicLungDisease.getCheckedRadioButtonId();
        rb24 = findViewById(radioButtonId24);

        int radioButtonId25 = mSpecifyCancer.getCheckedRadioButtonId();
        rb25 = findViewById(radioButtonId25);

        int radioButtonId26 = mSpecifyHeartDisease.getCheckedRadioButtonId();
        rb26 = findViewById(radioButtonId26);
    }
}